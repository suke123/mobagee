package jtp.c.dendai.ac.jp.shootingsample.mono;
import jtp.c.dendai.ac.jp.shootingsample.Vect;
public interface Shooter extends Mono {
    void shoot(Vect dp);
}