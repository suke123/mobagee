package jtp.c.dendai.ac.jp.shootingsample.mono;
import jtp.c.dendai.ac.jp.shootingsample.Vect;
public interface Shootable extends Mono {
    Shootable getInstance();
    void init(Vect p, Vect dp);
}