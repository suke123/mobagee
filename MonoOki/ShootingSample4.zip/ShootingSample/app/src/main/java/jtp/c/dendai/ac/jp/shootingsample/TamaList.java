package jtp.c.dendai.ac.jp.shootingsample;
import java.util.ArrayList;
import jtp.c.dendai.ac.jp.shootingsample.mono.Mono;
public class TamaList extends ArrayList<Mono> {
    public TamaList() {
        super();
    }
}