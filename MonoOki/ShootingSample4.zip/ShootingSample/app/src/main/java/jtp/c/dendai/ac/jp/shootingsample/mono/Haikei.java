package jtp.c.dendai.ac.jp.shootingsample.mono;
import jtp.c.dendai.ac.jp.shootingsample.R;
import jtp.c.dendai.ac.jp.shootingsample.Vect;
import android.content.Context;
import android.graphics.Canvas;
public class Haikei extends AbstractMono {
    private static final int[] ids = {R.drawable.haikei};
    public Haikei(Context context){
        super(context,ids);
        p.set(0,12);
    }
    @Override
    public void move(int width, int height) {
    }
}