package jp.ac.dendai.c.jtp.myapplication1.mono;
import jp.ac.dendai.c.jtp.myapplication1.Vect;
public interface Shooter extends Mono {
    void shoot(Vect dp);
}